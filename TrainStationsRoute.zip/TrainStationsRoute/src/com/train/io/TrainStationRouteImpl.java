package com.train.io;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.train.constants.TrainConstants;
import com.train.model.Train;

public class TrainStationRouteImpl implements TrainStationRoute, TrainsChartDetails {

	static {
		TrainsChartDetails.init();

	}

	@Override
	public String arrivalStatusBanner(String train) {
		StringBuilder arrivalBanner = new StringBuilder();

		arrivalBanner.append(TrainConstants.ARRIVAL);
		arrivalBanner.append(TrainConstants.SPACE);
		arrivalBanner.append(train);
		arrivalBanner.append(TrainConstants.SPACE);
		arrivalBanner.append(TrainConstants.ENGINE);

		return arrivalBanner.toString();

	}

	@Override
	public String departureStatusBanner(String train) {
		StringBuilder departureBanner = new StringBuilder();

		departureBanner.append(TrainConstants.ARRIVAL);
		departureBanner.append(TrainConstants.SPACE);
		departureBanner.append(train);
		departureBanner.append(TrainConstants.SPACE);
		departureBanner.append(TrainConstants.ENGINE);

		return departureBanner.toString();

	}

	@Override
	public List<Train> trainsArrivalRouteTillMergingStation(List<Train> list, int mergedStationDistance) {

		return list.stream().filter(t -> t.getDistance() >= mergedStationDistance).collect(Collectors.toList());
	}

	@Override
	public List<Train> trainsDepartureRouteFromMergingStation(List<Train> trainA, List<Train> trainB) {

		List<Train> mergedTrainList = Stream.of(trainA, trainB).flatMap(t -> t.stream()).collect(Collectors.toList());
		Collections.sort(mergedTrainList);
		return mergedTrainList.stream().filter(t -> t.getCode() != TrainConstants.TRAIN_AB_MERGING_STATION)
				.collect(Collectors.toList());

	}

}
