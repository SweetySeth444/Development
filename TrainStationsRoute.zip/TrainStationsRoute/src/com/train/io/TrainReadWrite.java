package com.train.io;

/**
 * Methods declared for performing read and write operation
 */
import java.util.List;

import com.train.model.Train;

public interface TrainReadWrite {

	public String[] read(String filepath);
	public void write(String statusBanner, List<Train> list);
}
