package com.train.io;

/**
 * Method declared to parse route for Trains
 */

import java.util.List;
import java.util.Map;

import com.train.model.Train;

public interface InputParser {
	
	public List<Train> parse(String data, Map<String, Train> source, Map<String, Train> merge);

}
