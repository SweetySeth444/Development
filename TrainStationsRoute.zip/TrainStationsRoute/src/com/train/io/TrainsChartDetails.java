package com.train.io;
/**
 * Keeping an account of Individual Trains route to their intermediate stations in the path of reaching destination
 */

import java.util.LinkedHashMap;
import java.util.Map;

import com.train.constants.StationCode;
import com.train.model.Train;

public interface TrainsChartDetails {
	


/*	Train A                   Train B
CHENNAI (CHN) - 0  	      TRIVANDRUM (TVC) - 0
SALEM (SLM) - 350	      SHORANUR (SRR) - 300
BANGALORE (BLR) - 550 -0  MANGALORE (MAQ) - 600
KURNOOL (KRN) - 900	      MADGAON (MAO) - 1000
HYDERABAD (HYB) - 1200	  PUNE (PNE) - 1400
NAGPUR (NGP) - 1600	      HYDERABAD (HYB) - 2000
ITARSI (ITJ) - 1900	      NAGPUR (NGP) - 2400
BHOPAL (BPL) - 2000	      ITARSI (ITJ) - 2700
AGRA (AGA) - 2500	      BHOPAL (BPL) - 2800
NEW DELHI (NDL) - 2700	  PATNA (PTA) - 3800
NEW JALPAIGURI (NJP) - 4200
GUWAHATI (GHY) - 4700
*/

	static Map<String, Train> TRAIN_A = new LinkedHashMap<>();
	static Map<String, Train> TRAIN_B = new LinkedHashMap<>();
	
	public static void init() {

		// Initializing Train A  & B Map
		TRAIN_A.put(StationCode.CHN.name(),new Train("CHENNAI", StationCode.CHN.name(), 0, false, true)); 
		TRAIN_A.put(StationCode.SLM.name(),new Train("SALEM", StationCode.SLM.name(), 350, false, true)); 
		TRAIN_A.put(StationCode.BLR.name(),new Train("BANGALORE", StationCode.BLR.name(), 550, false, true)); 
		TRAIN_A.put(StationCode.KRN.name(),new Train("KURNOOL", StationCode.KRN.name(), 900, false, true));
		TRAIN_A.put(StationCode.HYB.name(),new Train("HYDERABAD", StationCode.HYB.name(), 1200,true, false)); 
		TRAIN_A.put(StationCode.NGP.name(),new Train("NAGPUR", StationCode.NGP.name(), 1600,true, false)); 
		TRAIN_A.put(StationCode.ITJ.name(),new Train("ITARSI", StationCode.ITJ.name(), 1900,true, false)); 
		TRAIN_A.put(StationCode.BPL.name(),new Train("BHOPAL", StationCode.BPL.name(), 2000,true, false)); 
		TRAIN_A.put(StationCode.AGA.name(),new Train("AGRA", StationCode.AGA.name(), 2500,false,true)); 
		TRAIN_A.put(StationCode.NDL.name(),new Train("NEW DELHI", StationCode.NDL.name(), 2700,false,true)); 

		// Initializing Train B Map
		TRAIN_B.put(StationCode.TVC.name(),new Train("TRIVANDRUM", StationCode.TVC.name(), 0, false, true)); 
		TRAIN_B.put(StationCode.SRR.name(),new Train("SHORANUR", StationCode.SRR.name(), 300, false, true)); 
		TRAIN_B.put(StationCode.MAQ.name(),new Train("MANGALORE", StationCode.MAQ.name(), 600, false, true)); 
		TRAIN_B.put(StationCode.MAO.name(),new Train("MADGAON", StationCode.MAO.name(), 1000, false, true)); 
		TRAIN_B.put(StationCode.PNE.name(),new Train("PUNE", StationCode.PNE.name(), 1400, false, true)); 
		TRAIN_B.put(StationCode.HYB.name(),new Train("HYDERABAD", StationCode.HYB.name(), 2000,true, false)); 
		TRAIN_B.put(StationCode.NGP.name(),new Train("NAGPUR", StationCode.NGP.name(), 2400,true, false)); 
		TRAIN_B.put(StationCode.ITJ.name(),new Train("ITARSI", StationCode.ITJ.name(), 2700,true, false)); 
		TRAIN_B.put(StationCode.BPL.name(),new Train("BHOPAL", StationCode.BPL.name(), 2800,true, false)); 
		TRAIN_B.put(StationCode.PTA.name(),new Train("PATNA", StationCode.PTA.name(), 3800,false,true)); 
		TRAIN_B.put(StationCode.NJP.name(),new Train("NEW JALPAIGURI", StationCode.NJP.name(), 4200,false,true)); 
		TRAIN_B.put(StationCode.GHY.name(),new Train("GUWAHATI", StationCode.GHY.name(), 4700,false,true)); 

	}
	
	public static int getTrainDistance(String code, Map<String, Train> map) {
		return map.get(code).getDistance();
	}


}
