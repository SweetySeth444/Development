package com.train.io;
/**
 * Methods declared to calculate the output 
 * arrivalStatusBanner -> ARRIVAL (for train A) [till Hyderabad]
 *                        ARRIVAL (for train B)  [till Hyderabad]
 * departureStatusBanner->DEPARTURE (for trainAB) [from Hyderabad]
 * trainsArrivalRouteTillMergingStation -> Calculating ARRIVAL bogies for both Trains A & B
 * trainsDepartureRouteFromMergingStation -> Calculating DEPARTURE bogies for both Trains A & B in descending order.
 * 
 *                        
 */

import java.util.List;

import com.train.model.Train;

public interface TrainStationRoute {
	
	public String arrivalStatusBanner(String train);

	public String departureStatusBanner(String train);

	public List<Train> trainsArrivalRouteTillMergingStation(List<Train> list, int mergedStationDistance);

	public List<Train> trainsDepartureRouteFromMergingStation(List<Train> trainA, List<Train> trainB);

	
}
