package com.train.io;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.train.constants.TrainConstants;
import com.train.model.Train;

public class InputParserImpl implements InputParser {

	@Override
	public List<Train> parse(String data, Map<String, Train> source, Map<String, Train> merge) {
		List<Train> train = new ArrayList<>();

		String[] bogies = data.split(TrainConstants.SPACE);

		for (String bogie : bogies) {

			if (merge.get(bogie) != null && merge.get(bogie).isIndependent()) // consider train station available in
																				// train
				train.add(merge.get(bogie));
			if (source.get(bogie) != null && merge.get(bogie) != null
					&& source.get(bogie).getCode() != TrainConstants.TRAIN_AB_MERGING_STATION)
				if (source.get(bogie).getDistance() < merge.get(bogie).getDistance())
					train.add(source.get(bogie));
				else
					train.add(merge.get(bogie));
			else if (source.get(bogie) != null) // consider train station available in train route
				train.add(source.get(bogie));
		}

		return train;

	}
}