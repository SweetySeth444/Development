package com.train.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

import com.train.constants.TrainConstants;
import com.train.model.Train;

public class TrainReadWriteImpl implements TrainReadWrite {

	@Override
	public String[] read(String filePath) {
		String[] data = new String[2];
		int i = 0;
		try (Scanner scanner = new Scanner(new File(filePath));) {
			while (scanner.hasNextLine()) {
				data[i] = scanner.nextLine();
				i++;
			}
			return data;
		} catch (FileNotFoundException e) {
			System.out.println("Error occured while reading file data");
			e.printStackTrace();
		}

		return null;

	}

	@Override
	public void write(String StatusBanner, List<Train> list) {
		StringBuilder OutputResult = new StringBuilder();

		// If there are no passenger bogies to travel from Hyderabad station, then train
		// should stop there. In such a case it should print JOURNEY_ENDED
		if (list.isEmpty())
			System.out.println(StatusBanner + TrainConstants.SPACE + TrainConstants.JOURNEY_ENDED);
		else {
			for (Train train : list) {
				OutputResult.append(TrainConstants.SPACE);
				OutputResult.append(train.getCode());
			}

			System.out.println(StatusBanner + OutputResult);
		}
	}

}
