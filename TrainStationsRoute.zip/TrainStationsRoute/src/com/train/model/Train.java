package com.train.model;

/**
 * 
 * @author SweetySeth 
 * Structure of Train Model Attributes being -> name (Station Name), code (Station Code), distance(Distance covered till respective Station), isMerged ( is Station a part of a Merged TrainAB),
 * isIndependent (is Station currently a part of Individual Train)
 *
 */

public class Train implements Comparable<Train> {

	String name;
	String code;
	int distance;
	boolean isMerged;
	boolean isIndependent;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public boolean isMerged() {
		return isMerged;
	}

	public void setMerged(boolean isMerged) {
		this.isMerged = isMerged;
	}

	public boolean isIndependent() {
		return isIndependent;
	}

	public void setIndependent(boolean isIndependent) {
		this.isIndependent = isIndependent;
	}

	public Train(String name, String code, int distance, boolean merged, boolean independent) {
		super();
		this.name = name;
		this.code = code;
		this.distance = distance;
		this.isMerged = merged;
		this.isIndependent = independent;
	}

	@Override
	public int compareTo(Train result) {

		// For Descending order
		return result.getDistance() - this.distance;

	}

	@Override
	public String toString() {

		return name + " (" + code + ") - " + distance;
	}

}