package com.train.service;

/**
 * Main Class
 */

import java.util.List;

import com.train.constants.TrainConstants;
import com.train.io.InputParser;
import com.train.io.InputParserImpl;
import com.train.io.TrainReadWrite;
import com.train.io.TrainReadWriteImpl;
import com.train.io.TrainStationRoute;
import com.train.io.TrainStationRouteImpl;
import com.train.io.TrainsChartDetails;
import com.train.model.Train;

public class GeekTrust {

	public static void main(String[] args) {
		TrainReadWrite readFile = new TrainReadWriteImpl();
		TrainReadWrite writeToOutput = new TrainReadWriteImpl();
		TrainStationRoute stationRoute = new TrainStationRouteImpl();
		InputParser parseInput = new InputParserImpl();

		if (args.length != 0) {
			// Reading Data from File
			String data[] = readFile.read(args[0]);
			List<Train> trainA_route = parseInput.parse(data[0], TrainsChartDetails.TRAIN_A,
					TrainsChartDetails.TRAIN_B);
			List<Train> trainB_route = parseInput.parse(data[1], TrainsChartDetails.TRAIN_B,
					TrainsChartDetails.TRAIN_A);

			// Collecting the Station Codes List for Train A & Train B Arrival to Hyderabad
			// and Later listing the station codes for the route after Hyderabad as Merged
			// Train AB.

			List<Train> trainA_arrival = stationRoute.trainsArrivalRouteTillMergingStation(trainA_route,
					TrainsChartDetails.getTrainDistance(TrainConstants.TRAIN_AB_MERGING_STATION,
							TrainsChartDetails.TRAIN_A));
			List<Train> trainB_arrival = stationRoute.trainsArrivalRouteTillMergingStation(trainB_route,
					TrainsChartDetails.getTrainDistance(TrainConstants.TRAIN_AB_MERGING_STATION,
							TrainsChartDetails.TRAIN_B));
			List<Train> trainAB_departure = stationRoute.trainsDepartureRouteFromMergingStation(trainA_arrival,
					trainB_arrival);

			writeToOutput.write(stationRoute.arrivalStatusBanner(TrainConstants.TRAIN_A), trainA_arrival);
			writeToOutput.write(stationRoute.arrivalStatusBanner(TrainConstants.TRAIN_B), trainB_arrival);
			writeToOutput.write(stationRoute.departureStatusBanner(TrainConstants.TRAIN_AB), trainAB_departure);

		} else
			// if invalid or no file path provided
			System.out.println("File Path Not Found. Please enter a valid File Path");

	}
}